# FOLDER CONTENTS
This folder contains all (?) the files for a the underlying foundations of a Spotify login page using Google Cloud's App Engine and node.js.
It doesn't quite work... :(

We were able to get the Spotify API sample code working on a local machine, but encountered numerous issues when
deploying it to the App Engine.
